﻿using Portfolio.Static;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Portfolio
{
    /// <summary>
    /// Summary description for NutritionHandler
    /// </summary>
    public class NutritionHandler : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            if (context.Request.Params["Type"] == "Search")
            {
                context.Response.Write(this.Search(context));
            }
            else if (context.Request.Params["Type"] == "DropDown")
            {
                context.Response.Write(this.DropDown(context));
            }
            else if (context.Request.Params["Type"] == "NutritionProfileAdd")
            {
                context.Response.Write(this.NutritionProfileAdd(context));
            }
            else if (context.Request.Params["Type"] == "ProfileSearch")
            {
                context.Response.Write(this.ProfileSearch(context));
            }
            else if (context.Request.Params["Type"] == "UpdateEntry")
            {
                context.Response.Write(this.UpdateEntry(context));
            }
            else if (context.Request.Params["Type"] == "DeleteEntry")
            {
                context.Response.Write(this.DeleteEntry(context));
            }
            else if (context.Request.Params["Type"] == "Login")
            {
                context.Response.Write(this.Login(context));
            }
            else if (context.Request.Params["Type"] == "UpdateProfile")
            {
                context.Response.Write(this.UpdateProfile(context));
            }
            else if (context.Request.Params["Type"] == "LogOut")
            {
                this.LogOut();
            }
        }

        private string Search(HttpContext context)
        {
            string[] parameters = new string[] {"Calories", "Water", "Protein", "Lipid", "Carbohydrate", "Fiber", "Sugar", "Calcium", "Iron"};
            Table table = new Table();
            table.ID = "domainsTable";
            table.CssClass = "tablesorter";
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Food_Nutrition_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@Name", SqlDbType.VarChar);
                    command.Parameters["@Name"].Value = context.Request.Params["FoodName"];
                    decimal num;
                    foreach (var parameter in parameters)
                    {
                        if (decimal.TryParse(context.Request.Params["Min" + parameter], out num))
                        {
                            command.Parameters.Add("@Min" + parameter, SqlDbType.Decimal);
                            command.Parameters["@Min" + parameter].Value = num;
                        }

                        if (decimal.TryParse(context.Request.Params["Max" + parameter], out num))
                        {
                            command.Parameters.Add("@Max" + parameter, SqlDbType.Decimal);
                            command.Parameters["@Max" + parameter].Value = num;
                        }
                    }
                    
                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        table.Rows.Add(ProfileLibrary.CreateFoodNutritionHeader(false));
                        TableRow tr;
                        while (reader.Read())
                        {
                            tr = ProfileLibrary.CreateFoodNutritionBodyRow(false, reader);
                            tr.Attributes.Add("onclick", "SelectFood(this);");
                            tr.Attributes.Add("foodkey", reader["Food_Key"].ToString());
                            tr.Attributes.Add("foodunitkey", reader["Food_Unit_Key"].ToString());
                            tr.Attributes.Add("foodname", reader["Name"].ToString());
                            table.Rows.Add(tr);
                        }
                    }
                    conn.Close();
                }
            }

            StringWriter theStringWriter = new StringWriter();
            HtmlTextWriter theHtmlTextWriter = new HtmlTextWriter(theStringWriter);

            // Render the table row control into the writer
            table.RenderControl(theHtmlTextWriter);

            // Return the string via the StringWriter
            return theStringWriter.ToString();
            
        }

        private string DropDown(HttpContext context)
        {
            DropDownList list = new DropDownList();
            list.ID = "FoodUnitList";

            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Food_Units_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    command.Parameters.Add("@Food_Key", SqlDbType.Int);
                    command.Parameters["@Food_Key"].Value = context.Request.Params["FoodKey"];
                    conn.Open();
                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    list.DataSource = reader;
                    list.DataTextField = "Unit_Name";
                    list.DataValueField = "Unit_Key";
                    list.DataBind();
                    conn.Close();
                    using (var command2 = new SqlCommand("dbo.Food_Unit_Get", conn)
                    {
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        conn.Open();
                        command2.Parameters.Add("@Food_Key", SqlDbType.Int);
                        command2.Parameters["@Food_Key"].Value = context.Request.Params["FoodKey"];
                        // Create parameter with Direction as Output (and correct name and type)
                        SqlParameter outputIdParam = new SqlParameter("@Unit_Key", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Output
                        };

                        command2.CommandType = CommandType.StoredProcedure;
                        command2.Parameters.Add(outputIdParam);
                        command2.ExecuteNonQuery();
                        list.SelectedValue = outputIdParam.Value.ToString();
                        conn.Close();
                    }
                }
            }

            StringWriter theStringWriter = new StringWriter();
            HtmlTextWriter theHtmlTextWriter = new HtmlTextWriter(theStringWriter);

            // Render the table row control into the writer
            list.RenderControl(theHtmlTextWriter);

            // Return the string via the StringWriter
            return theStringWriter.ToString();
        }

        private string NutritionProfileAdd(HttpContext context)
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Nutrition_Profile_Add", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    command.Parameters.Add("@Food_Key", SqlDbType.Int);
                    command.Parameters["@Food_Key"].Value = context.Request.Params["FoodKey"];
                    command.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    command.Parameters["@Quantity"].Value = context.Request.Params["Quantity"];
                    command.Parameters.Add("@Unit_Key", SqlDbType.Decimal);
                    command.Parameters["@Unit_Key"].Value = context.Request.Params["UnitKey"];
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }

            return "Food was successfully added to profile";
        }

        private string ProfileSearch(HttpContext context)
        {
            Table table = new Table();
            table.ID = "nutritionProfileTable";
            table.CssClass = "tablesorter";
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Nutrition_Profile_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    var date = new DateTime();
                    if (DateTime.TryParse(context.Request["AddDateFrom"], out date))
                    {
                        command.Parameters.Add("@Add_Date_From", SqlDbType.DateTime);
                        command.Parameters["@Add_Date_From"].Value = date;
                        HttpContext.Current.Session["Add_Date_From"] = context.Request["AddDateFrom"];
                    }

                    if (DateTime.TryParse(context.Request["AddDateTo"], out date))
                    {
                        command.Parameters.Add("@Add_Date_To", SqlDbType.DateTime);
                        command.Parameters["@Add_Date_To"].Value = date;
                        HttpContext.Current.Session["Add_Date_To"] = context.Request["AddDateTo"];
                    }

                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        table.Rows.Add(ProfileLibrary.CreateFoodNutritionHeader(true));
                        TableRow tr;
                        while (reader.Read())
                        {
                            tr = ProfileLibrary.CreateFoodNutritionBodyRow(true, reader);
                            table.Rows.Add(tr);
                        }
                    }
                    conn.Close();
                }
            }

            StringWriter theStringWriter = new StringWriter();
            HtmlTextWriter theHtmlTextWriter = new HtmlTextWriter(theStringWriter);

            // Render the table row control into the writer
            table.RenderControl(theHtmlTextWriter);

            // Return the string via the StringWriter
            return theStringWriter.ToString();

        }

        private string UpdateEntry(HttpContext context)
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Nutrition_Profile_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    command.Parameters.Add("@Nutrition_History_Key", SqlDbType.Int);
                    command.Parameters["@Nutrition_History_Key"].Value = context.Request.Params["NutritionHistoryKey"];
                    command.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    command.Parameters["@Quantity"].Value = context.Request.Params["Quantity"];
                    command.Parameters.Add("@Unit_Key", SqlDbType.Decimal);
                    command.Parameters["@Unit_Key"].Value = context.Request.Params["UnitKey"];
                    var date = new DateTime();
                    if (DateTime.TryParse(context.Request.Params["AddDate"], out date))
                    {
                        command.Parameters.Add("@Add_Date", SqlDbType.DateTime);
                        command.Parameters["@Add_Date"].Value = context.Request.Params["AddDate"];
                    }
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }

            return "Record was successfully updated";
        }

        private string DeleteEntry(HttpContext context)
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Nutrition_Profile_Delete", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    command.Parameters.Add("@Nutrition_History_Key", SqlDbType.Int);
                    command.Parameters["@Nutrition_History_Key"].Value = context.Request.Params["NutritionHistoryKey"];
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }

            return "Record was successfully deleted";
        }

        private string Login(HttpContext context)
        {
            HttpContext.Current.Session["Add_Date_From"] = "";
            HttpContext.Current.Session["Add_Date_To"] = "";
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                string storedProcedureName;
                if (Boolean.Parse(context.Request.Params["Login"]))
                {
                    storedProcedureName = "dbo.User_Get";
                }
                else
                {
                    storedProcedureName = "dbo.User_Create";
                }

                using (var command = new SqlCommand(storedProcedureName, conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Name", SqlDbType.VarChar);
                    command.Parameters["@User_Name"].Value = context.Request.Params["UserName"];
                    command.Parameters.Add("@Password", SqlDbType.VarChar);
                    command.Parameters["@Password"].Value = context.Request.Params["Password"];

                    // Create parameter with Direction as Output (and correct name and type)
                    var userKeyOutput = new SqlParameter("@User_Key", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };

                    command.Parameters.Add(userKeyOutput);

                    var existsOutput = new SqlParameter("@Exists", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };

                    command.Parameters.Add(existsOutput);
                    command.ExecuteNonQuery();
                    conn.Close();
                    if (Boolean.Parse(context.Request.Params["Login"]))
                    {
                        if (Boolean.Parse(existsOutput.Value.ToString()))
                        {
                            context.Session["User_Key"] = Int32.Parse(userKeyOutput.Value.ToString());
                            return "Successful";
                        }
                        else
                        {
                            return "The supplied user name and password combination is not valid";
                        }
                    }
                    else
                    {
                        if (Boolean.Parse(existsOutput.Value.ToString()))
                        {
                            return "The supplied user name already exists";
                        }
                        else
                        {
                            context.Session["User_Key"] = Int32.Parse(userKeyOutput.Value.ToString());
                            return "Successful";
                        }
                    }
                }
            }
        }

        private string UpdateProfile(HttpContext context)
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.User_Profile_Add", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    command.Parameters.Add("@First_Name", SqlDbType.VarChar);
                    command.Parameters["@First_Name"].Value = context.Request.Params["FirstName"];
                    command.Parameters.Add("@Last_Name", SqlDbType.VarChar);
                    command.Parameters["@Last_Name"].Value = context.Request.Params["LastName"];
                    command.Parameters.Add("@Middle_Name", SqlDbType.VarChar);
                    command.Parameters["@Middle_Name"].Value = context.Request.Params["MiddleName"];
                    command.Parameters.Add("@Address", SqlDbType.VarChar);
                    command.Parameters["@Address"].Value = context.Request.Params["Address"];
                    command.Parameters.Add("@City", SqlDbType.VarChar);
                    command.Parameters["@City"].Value = context.Request.Params["City"];
                    command.Parameters.Add("@State", SqlDbType.VarChar);
                    command.Parameters["@State"].Value = context.Request.Params["State"];
                    command.Parameters.Add("@Country", SqlDbType.VarChar);
                    command.Parameters["@Country"].Value = context.Request.Params["Country"];
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }

            return "Record was successfully updated";
        }

        private void LogOut()
        {
            HttpContext.Current.Session["User_Key"] = null;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}