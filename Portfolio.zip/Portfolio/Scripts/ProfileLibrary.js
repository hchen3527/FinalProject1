﻿function OnComplete(result)
{
    alert("Hello");
}

function LogOutRedirect(result)
{
    window.location = "Login.aspx";
}

function HandlerCall(filterData, finishCall)
{
    $.ajax({
        url: "Handler/NutritionHandler.ashx",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: filterData,
        responseType: "json",
        success: OnComplete,
        error: finishCall
    });
}

function LogOut(food)
{
    var filterData = {
        "Type": "LogOut"
    };

    HandlerCall(filterData, LogOutRedirect);
}

function ValidateRequired()
{
    var requiredElements = $(".Required");
    for (i = 0; i < requiredElements.length; i++)
    {
        if($(requiredElements[i]).val() == "")
        {
            alert($(requiredElements[i]).attr("displayname").toString() + " is required.")
            return false;
        }
    }

    var requiredElements = $(".NoWhiteSpace");
    for (i = 0; i < requiredElements.length; i++)
    {
        if ($(requiredElements[i]).val().indexOf(" ") > -1)
        {
            alert($(requiredElements[i]).attr("displayname").toString() + " cannot have white space.")
            return false;
        }
    }

    return true;
}

Date.prototype.yyyymmdd = function ()
{
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
    var dd = this.getDate().toString();
    return yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]); // padding
};

function CheckIsNum(object)
{
    var val = $(object).val();
    if (val == "")
    {
        return;
    }

    if (isNaN(parseFloat(val)) || isFinite(val) == false)
    {
        $(object).val(0);
    }
    else if (parseFloat(val) < 0)
    {
        $(object).val(0);
    }
}