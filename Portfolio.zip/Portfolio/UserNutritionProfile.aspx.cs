﻿using Portfolio.Static;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI.WebControls;

namespace Portfolio
{
    public partial class UserNutritionProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ProfileLibrary.SessionExists();
            this.UserProfilePopulate();
            this.NutritionProfilePopulate();
        }

        private void UserProfilePopulate()
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.User_Profile_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    ProfileLibrary.AddTableStyling(this.userInformationTable);
                    if (reader.HasRows)
                    {
                        reader.Read();
                        TableHeaderRow header = new TableHeaderRow();
                        var cell = new TableHeaderCell { Text = "Nutrition Profile", ColumnSpan = 2, };
                        ProfileLibrary.AddHeaderCellStyling(cell);
                        header.Cells.Add(cell);
                        this.userInformationTable.Rows.Add(header);

                        TableRow tr = new TableRow();
                        tr.Cells.Add(new TableCell { Text = "Name:", CssClass = "FilterLabel" });
                        tr.Cells.Add(new TableCell { Text = reader["First_Name"].ToString() + " " + reader["Last_Name"].ToString(), CssClass = "FilterInput" });
                        this.userInformationTable.Rows.Add(tr);

                        tr = new TableRow();
                        tr.Cells.Add(new TableCell { Text = "Address:", CssClass = "FilterLabel" });
                        tr.Cells.Add(new TableCell { Text = reader["Address"].ToString(), CssClass = "FilterInput" });
                        this.userInformationTable.Rows.Add(tr);

                        tr = new TableRow();
                        tr.Cells.Add(new TableCell { Text = "City:", CssClass = "FilterLabel" });
                        tr.Cells.Add(new TableCell { Text = reader["City"].ToString(), CssClass = "FilterInput" });
                        this.userInformationTable.Rows.Add(tr);

                        tr = new TableRow();
                        tr.Cells.Add(new TableCell { Text = "State:", CssClass = "FilterLabel" });
                        tr.Cells.Add(new TableCell { Text = reader["State"].ToString(), CssClass = "FilterInput" });
                        this.userInformationTable.Rows.Add(tr);

                        tr = new TableRow();
                        tr.Cells.Add(new TableCell { Text = "Country:", CssClass = "FilterLabel" });
                        tr.Cells.Add(new TableCell { Text = reader["Country"].ToString(), CssClass = "FilterInput" });
                        this.userInformationTable.Rows.Add(tr);
                    }
                    conn.Close();
                }
            }
        }

        private void NutritionProfilePopulate()
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Nutrition_Profile_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    command.Parameters.Add("@Add_Date_From", SqlDbType.DateTime);
                    command.Parameters.Add("@Add_Date_To", SqlDbType.DateTime);
                    string addDateFrom = string.IsNullOrEmpty(HttpContext.Current.Session["Add_Date_From"].ToString()) ? DateTime.Now.ToString("yyyy-MM-dd") : HttpContext.Current.Session["Add_Date_From"].ToString();
                    HttpContext.Current.Session["Add_Date_From"] = addDateFrom;
                    this.Add_Date_From.Attributes.Add("val", addDateFrom);
                    command.Parameters["@Add_Date_From"].Value = addDateFrom;
                    string addDateTo = string.IsNullOrEmpty(HttpContext.Current.Session["Add_Date_To"].ToString()) ? DateTime.Now.ToString("yyyy-MM-dd") : HttpContext.Current.Session["Add_Date_To"].ToString();
                    HttpContext.Current.Session["Add_Date_To"] = addDateTo;
                    this.Add_Date_To.Attributes.Add("val", addDateTo);
                    command.Parameters["@Add_Date_To"].Value = addDateTo;

                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        this.nutritionProfileTable.Rows.Add(ProfileLibrary.CreateFoodNutritionHeader(true));
                        TableRow tr;
                        while (reader.Read())
                        {
                            tr = ProfileLibrary.CreateFoodNutritionBodyRow(true, reader);
                            this.nutritionProfileTable.Rows.Add(tr);
                        }
                    }
                    conn.Close();
                }
            }
        }
    }
}