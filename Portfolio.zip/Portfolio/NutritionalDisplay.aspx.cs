﻿using Portfolio.Static;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Portfolio
{
    public partial class NutritionalDisplay : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ProfileLibrary.SessionExists();
            this.PopulateNutritionGrid();
        }

        private void PopulateNutritionGrid()
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.Food_Nutrition_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        this.domainsTable.Rows.Add(ProfileLibrary.CreateFoodNutritionHeader(false));
                        TableRow tr;
                        while (reader.Read())
                        {
                            tr = ProfileLibrary.CreateFoodNutritionBodyRow(false, reader);
                            tr.Attributes.Add("onclick", "SelectFood(this);");
                            tr.Attributes.Add("foodkey", reader["Food_Key"].ToString());
                            tr.Attributes.Add("foodunitkey", reader["Food_Unit_Key"].ToString());
                            this.domainsTable.Rows.Add(tr);
                        }
                    }
                    conn.Close();
                }
            }
        }
    }
}