﻿using Portfolio.Static;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace Portfolio
{
    public partial class NewUserForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ProfileLibrary.SessionExists();
            this.PopulateUserProfileForm();
        }

        private void PopulateUserProfileForm()
        {
            using (var conn = new SqlConnection("Server=(local);DataBase=Nutrition;Integrated Security=SSPI"))
            {
                using (var command = new SqlCommand("dbo.User_Profile_Get", conn)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    conn.Open();
                    command.Parameters.Add("@User_Key", SqlDbType.Int);
                    command.Parameters["@User_Key"].Value = HttpContext.Current.Session["User_Key"];
                    var reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        reader.Read();
                        this.firstNameInput.Value = reader["First_Name"].ToString();
                        this.lastNameInput.Value = reader["Last_Name"].ToString();
                        this.middleNameInput.Value = reader["Middle_Name"].ToString();
                        this.addressInput.Value = reader["Address"].ToString();
                        this.cityInput.Value = reader["City"].ToString();
                        this.stateInput.Value = reader["State"].ToString();
                        this.countryInput.Value = reader["Country"].ToString();
                    }
                    conn.Close();
                }
            }
        }
    }
}