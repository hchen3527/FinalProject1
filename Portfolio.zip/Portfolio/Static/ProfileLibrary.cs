﻿using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Portfolio.Static
{
    public static class ProfileLibrary
    {
        public static void SessionExists()
        {
            if (HttpContext.Current.Session["User_Key"] == null)
            {
                HttpContext.Current.Response.Redirect("Login.aspx");
            }
        }

        public static void AddTableStyling(Table table)
        {
            table.Style.Add(HtmlTextWriterStyle.Margin, "auto");
            table.Style.Add(HtmlTextWriterStyle.BorderWidth, "3px");
            table.Style.Add(HtmlTextWriterStyle.BorderStyle, "solid");
            table.Style.Add(HtmlTextWriterStyle.BorderColor, "#8dbdd8");
            table.Style.Add(HtmlTextWriterStyle.BackgroundColor, "#CDCDCD");
        }

        public static void AddHeaderCellStyling(TableHeaderCell cell)
        {
            cell.Style.Add("border-bottom-width", "2px");
            cell.Style.Add("border-bottom-style", "solid");
            cell.Style.Add("border-bottom-color", "#8dbdd8");
        }

        public static TableHeaderRow CreateFoodNutritionHeader(bool ShowQuantityandUnit)
        {
            TableHeaderRow header = new TableHeaderRow();
            header.Cells.Add(new TableHeaderCell { Text = "Food Name" });
            if (ShowQuantityandUnit)
            {
                header.Cells.Add(new TableHeaderCell { Text = "Quantity" });
                header.Cells.Add(new TableHeaderCell { Text = "Unit" });
            }
            header.Cells.Add(new TableHeaderCell { Text = "Calories" });
            header.Cells.Add(new TableHeaderCell { Text = "Water" });
            header.Cells.Add(new TableHeaderCell { Text = "Protein" });
            header.Cells.Add(new TableHeaderCell { Text = "Lipid" });
            header.Cells.Add(new TableHeaderCell { Text = "Carbohydrate" });
            header.Cells.Add(new TableHeaderCell { Text = "Fiber" });
            header.Cells.Add(new TableHeaderCell { Text = "Sugar" });
            header.Cells.Add(new TableHeaderCell { Text = "Calcium" });
            header.Cells.Add(new TableHeaderCell { Text = "Iron" });
            header.TableSection = TableRowSection.TableHeader;
            return header;
        }

        public static TableRow CreateFoodNutritionBodyRow(bool ShowQuantityandUnit, SqlDataReader reader)
        {
            var tr = new TableRow();
            if (ShowQuantityandUnit)
            {
                var link = new HyperLink();
                link.Text = reader["Name"].ToString();
                link.NavigateUrl = "NutritionProfileForm.aspx?Nutrition_History_Key=" + reader["Nutrition_History_Key"].ToString();
                var cell = new TableCell();
                cell.Controls.Add(link);
                tr.Cells.Add(cell);
                tr.Cells.Add(new TableCell { Text = reader["Quantity"].ToString(), CssClass = "Number" });
                tr.Cells.Add(new TableCell { Text = reader["Unit_Name"].ToString() });
            }
            else
            {
                tr.Cells.Add(new TableCell { Text = reader["Name"].ToString() });
            }
            tr.Cells.Add(new TableCell { Text = reader["Calories"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Water"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Protein"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Lipid"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Carbohydrate"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Fiber"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Sugar"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Calcium"].ToString(), CssClass = "Number" });
            tr.Cells.Add(new TableCell { Text = reader["Iron"].ToString(), CssClass = "Number" });
            return tr;
        }
    }
}